/* =========================================================
   종이마음 · 앱 로직 (순수 JS, 의존성 없음)
   - 해시 기반 라우터
   - 편지 작성 → 종이접기 선택 → 접기 애니메이션 → 미리보기 → 전송(공유링크) → 편지함
   - 서버가 없는 정적 배포(GH Pages) 환경이므로
     "전송"은 편지 내용을 URL에 안전하게 인코딩한 공유 링크로 구현한다.
     로컬 편지함은 localStorage에 보관한다.
   ========================================================= */

(function () {
  'use strict';

  /* ---------------- 종이접기 형태 정의 ---------------- */
  // 각 형태는 아이콘(SVG path)과 짧은 감성 문구를 가진다.
  const FOLDS = {
    plane: {
      name: '종이비행기',
      tag: '멀리, 빠르게 닿기를',
      icon: '<path d="M2 12L22 3l-6 18-4-7-7-2z"/><path d="M22 3L11 13"/>'
    },
    heart: {
      name: '하트',
      tag: '마음을 그대로',
      icon: '<path d="M12 21s-7.5-4.6-10-9.3C.4 8.4 2 5 5.2 5c2 0 3.3 1.2 4.1 2.4C10.1 6.2 11.4 5 13.4 5 16.6 5 18.2 8.4 16.6 11.7 14.9 15.1 12 21 12 21z"/>'
    },
    star: {
      name: '별',
      tag: '오래 빛나기를',
      icon: '<path d="M12 2.5l2.9 5.9 6.6.9-4.8 4.6 1.1 6.5L12 17.8 6.2 20.9l1.1-6.5L2.5 9.8l6.6-.9z"/>'
    },
    boat: {
      name: '종이배',
      tag: '흘러흘러 닿기를',
      icon: '<path d="M3 13h18l-2.5 5a2 2 0 0 1-1.8 1H7.3a2 2 0 0 1-1.8-1L3 13z"/><path d="M12 13V3l7 6"/><path d="M12 6L7 9"/>'
    },
    envelope: {
      name: '편지봉투',
      tag: '단정하게 담아',
      icon: '<rect x="3" y="5.5" width="18" height="13" rx="2"/><path d="M3.5 6.5L12 13l8.5-6.5"/>'
    }
  };
  const FOLD_KEYS = Object.keys(FOLDS);

  /* ---------------- 편지지 색상 ---------------- */
  const PAPERS = [
    { id: 'cream',   label: '크림',   color: '#f7f3ef' },
    { id: 'butter',  label: '버터',   color: '#fff4cf' },
    { id: 'blossom', label: '연분홍', color: '#ffe1e6' },
    { id: 'sky',     label: '연하늘', color: '#e4f1ff' },
    { id: 'mint',    label: '민트',   color: '#ddf1e9' }
  ];

  /* ---------------- 작성 중인 편지 (메모리 보관) ---------------- */
  const draft = {
    to: '',
    from: '',
    message: '',
    fold: 'plane',
    paper: 'cream'
  };

  /* ---------------- 저장소 (localStorage) ---------------- */
  const STORE = {
    received: 'jongi_received',
    sent: 'jongi_sent'
  };
  function load(key) {
    try { return JSON.parse(localStorage.getItem(key)) || []; }
    catch (e) { return []; }
  }
  function save(key, list) {
    try { localStorage.setItem(key, JSON.stringify(list)); } catch (e) {}
  }

  /* ---------------- 유틸 ---------------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const app = $('#app');

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // 한글 받침 유무로 목적격 조사(을/를) 선택
  function eul(word) {
    const w = String(word || '');
    const last = w.charCodeAt(w.length - 1);
    if (last >= 0xac00 && last <= 0xd7a3) {
      return ((last - 0xac00) % 28 !== 0) ? '을' : '를';
    }
    return '를';
  }

  function paperColor(id) {
    const p = PAPERS.find(x => x.id === id);
    return p ? p.color : '#f7f3ef';
  }

  // 접는 모양별 파스텔 블롭 색 (레퍼런스 팔레트)
  const FOLD_COLORS = { plane: '#a9d3ff', heart: '#ffb5c1', star: '#ffe59a', boat: '#b7e1d1', envelope: '#f1ece5' };
  function foldColor(key) { return FOLD_COLORS[key] || '#f1ece5'; }

  function foldIcon(key, size) {
    const f = FOLDS[key] || FOLDS.plane;
    const s = size || 40;
    return `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none"
      stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">${f.icon}</svg>`;
  }

  // UTF-8 안전한 base64 (한글 깨짐 방지)
  function encodeLetter(obj) {
    const json = JSON.stringify(obj);
    const b64 = btoa(unescape(encodeURIComponent(json)));
    return b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function decodeLetter(str) {
    try {
      let b64 = str.replace(/-/g, '+').replace(/_/g, '/');
      while (b64.length % 4) b64 += '=';
      return JSON.parse(decodeURIComponent(escape(atob(b64))));
    } catch (e) { return null; }
  }

  function formatDate(ts) {
    const d = new Date(ts);
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${d.getFullYear()}. ${mm}. ${dd}`;
  }

  let toastTimer = null;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.hidden = false;
    requestAnimationFrame(() => t.classList.add('show'));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      t.classList.remove('show');
      setTimeout(() => { t.hidden = true; }, 300);
    }, 2200);
  }

  function updateInboxBadge() {
    const badge = $('#inboxBadge');
    const unread = load(STORE.received).filter(m => !m.read).length;
    if (unread > 0) { badge.hidden = false; badge.textContent = unread; }
    else { badge.hidden = true; }
  }

  /* 진행 단계 표시 (쓰기 → 접기 → 보내기) */
  function stepper(active) {
    const steps = [['write', '쓰기'], ['fold', '접기'], ['send', '보내기']];
    const order = steps.map(s => s[0]);
    const idx = order.indexOf(active);
    return `<div class="stepper">` + steps.map((s, i) => {
      const cls = i < idx ? 'done' : (i === idx ? 'active' : '');
      const dot = i < idx ? '✓' : (i + 1);
      return `<span class="sp ${cls}"><span class="sp-dot">${dot}</span>${s[1]}</span>` +
        (i < steps.length - 1 ? '<span class="sp-line"></span>' : '');
    }).join('') + `</div>`;
  }

  /* =========================================================
     라우터
     ========================================================= */
  const routes = {
    '/home': renderHome,
    '/write': renderWrite,
    '/fold': renderFold,
    '/preview': renderPreview,
    '/send': renderSend,
    '/inbox': renderInbox
  };

  function router() {
    const raw = location.hash.replace(/^#/, '') || '/home';

    // 받은 편지 열기:  #/open=<encoded>
    if (raw.indexOf('/open=') === 0) {
      renderOpen(raw.slice('/open='.length));
      window.scrollTo(0, 0);
      return;
    }

    const path = raw.split('?')[0];
    const view = routes[path] || renderHome;
    view();
    updateInboxBadge();
    window.scrollTo(0, 0);
  }

  function go(path) { location.hash = path; }

  /* =========================================================
     화면: 홈
     ========================================================= */
  function renderHome() {
    app.innerHTML = `
      <section class="view">
        <div class="hero">
          <div>
            <p class="hero-eyebrow">디지털로 접는 손편지</p>
            <h1 class="hero-title">마음을 쓰고,<br/>한 번 더 <span class="mark-hl">접어</span><br/>보냅니다.</h1>
            <p class="hero-desc">빠른 메시지에 익숙해진 요즘, 직접 쓰고 접어 건네던 정성을
              화면 안에서 다시 느껴보세요. 편지를 접는 그 잠깐이, 마음을 한 번 더 눌러 담는 시간이 됩니다.</p>
            <div class="btn-row">
              <a class="btn btn-primary" href="#/write" data-link>편지 쓰러 가기</a>
              <a class="btn btn-ghost" href="#/inbox" data-link>편지함 열기</a>
            </div>
          </div>
          <div class="hero-art">
            <div class="mascot" aria-hidden="true">
              <div class="m-yellow"></div>
              <div class="m-body"></div>
              <div class="m-eyes"><span></span><span></span></div>
            </div>
          </div>
        </div>

        <h2 class="section-title">이렇게 전해져요</h2>
        <p class="section-sub">네 번의 작은 단계로, 손편지의 결을 그대로 옮겼습니다.</p>
        <div class="steps">
          <div class="step"><div class="step-no">01</div><div class="step-title">편지 쓰기</div>
            <div class="step-desc">받는 사람과 마음을 적고, 어울리는 편지지 색을 고릅니다.</div></div>
          <div class="step"><div class="step-no">02</div><div class="step-title">모양 접기</div>
            <div class="step-desc">비행기·하트·별·배·봉투. 마음에 맞는 모양으로 접습니다.</div></div>
          <div class="step"><div class="step-no">03</div><div class="step-title">접힘을 보기</div>
            <div class="step-desc">한 칸 한 칸 접히는 과정을 눈으로 따라가 봅니다.</div></div>
          <div class="step"><div class="step-no">04</div><div class="step-title">전하기</div>
            <div class="step-desc">완성된 편지를 링크로 건네면, 상대가 펼쳐 봅니다.</div></div>
        </div>
      </section>`;
  }

  /* =========================================================
     화면: 편지 쓰기
     ========================================================= */
  function renderWrite() {
    app.innerHTML = `
      <section class="view">
        ${stepper('write')}
        <h2 class="section-title">편지를 씁니다</h2>
        <p class="section-sub">천천히, 하고 싶던 말을 그대로 적어 보세요.</p>
        <div class="write-grid">
          <div>
            <div class="two-col">
              <div class="field">
                <label for="to">받는 사람</label>
                <input class="input" id="to" type="text" maxlength="20" placeholder="예: 수민" />
              </div>
              <div class="field">
                <label for="from">보내는 사람</label>
                <input class="input" id="from" type="text" maxlength="20" placeholder="예: 지호" />
              </div>
            </div>
            <div class="field">
              <label for="message">편지 내용</label>
              <textarea class="textarea" id="message" rows="9" maxlength="600"
                placeholder="이곳에 마음을 적어 주세요."></textarea>
              <div class="counter"><span id="count">0</span> / 600</div>
            </div>
            <div class="field">
              <label>편지지 색</label>
              <div class="swatches" id="swatches">
                ${PAPERS.map(p => `<button type="button" class="swatch" data-paper="${p.id}"
                  title="${p.label}" style="background:${p.color}"
                  aria-pressed="${draft.paper === p.id}"></button>`).join('')}
              </div>
            </div>
            <div class="btn-row">
              <button class="btn btn-primary" id="toFold">접으러 가기</button>
            </div>
          </div>

          <div>
            <span class="field-label">미리보기</span>
            <div class="letter-preview is-empty" id="preview" style="background-color:${paperColor(draft.paper)}">
              <div class="lp-to" id="pvTo"></div>
              <div class="lp-body" id="pvBody">여기에 적은 내용이 보여요…</div>
              <div class="lp-from" id="pvFrom"></div>
            </div>
          </div>
        </div>
      </section>`;

    // 값 복원
    const elTo = $('#to'), elFrom = $('#from'), elMsg = $('#message');
    elTo.value = draft.to; elFrom.value = draft.from; elMsg.value = draft.message;

    const pvTo = $('#pvTo'), pvBody = $('#pvBody'), pvFrom = $('#pvFrom'), preview = $('#preview');
    const count = $('#count');

    function syncPreview() {
      draft.to = elTo.value;
      draft.from = elFrom.value;
      draft.message = elMsg.value;
      pvTo.textContent = draft.to ? `${draft.to}에게` : '';
      pvFrom.textContent = draft.from ? `— ${draft.from}` : '';
      const hasMsg = draft.message.trim().length > 0;
      pvBody.textContent = hasMsg ? draft.message : '여기에 적은 내용이 보여요…';
      preview.classList.toggle('is-empty', !hasMsg);
      count.textContent = draft.message.length;
    }
    syncPreview();

    [elTo, elFrom, elMsg].forEach(el => el.addEventListener('input', syncPreview));

    // 편지지 색
    $('#swatches').addEventListener('click', (e) => {
      const b = e.target.closest('.swatch');
      if (!b) return;
      draft.paper = b.dataset.paper;
      $$('.swatch').forEach(s => s.setAttribute('aria-pressed', s === b));
      preview.style.backgroundColor = paperColor(draft.paper);
    });

    $('#toFold').addEventListener('click', () => {
      if (!draft.message.trim()) { toast('편지 내용을 적어 주세요.'); elMsg.focus(); return; }
      go('/fold');
    });
  }
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  /* =========================================================
     화면: 종이접기 선택 + 접기 애니메이션
     ========================================================= */
  function renderFold() {
    if (!draft.message.trim()) { go('/write'); return; }

    app.innerHTML = `
      <section class="view">
        ${stepper('fold')}
        <h2 class="section-title">어떤 모양으로 접을까요</h2>
        <p class="section-sub">담긴 마음에 어울리는 모양을 골라 보세요.</p>

        <div class="fold-pick" id="foldPick">
          ${FOLD_KEYS.map(k => `
            <button type="button" class="fold-opt" data-fold="${k}" aria-pressed="${draft.fold === k}">
              <div class="fo-icon">${foldIcon(k, 40)}</div>
              <div class="fo-name">${FOLDS[k].name}</div>
              <div class="fo-tag">${FOLDS[k].tag}</div>
            </button>`).join('')}
        </div>

        <div class="fold-stage" id="foldStage">
          <div class="origami" id="origami" style="--paper:${paperColor(draft.paper)}">
            <div class="opanel p-mid"><div class="face front"><div class="ftext">${esc(draft.message)}</div></div><div class="face back"></div></div>
            <div class="opanel p-bot"><div class="face front"><div class="ftext">${esc(draft.message)}</div></div><div class="face back"></div></div>
            <div class="opanel p-top"><div class="face front"><div class="ftext">${esc(draft.message)}</div></div><div class="face back"></div></div>
          </div>
          <div class="fold-result" id="foldResult">
            <div class="fr-shape" id="frShape"></div>
            <div class="fr-caption" id="frCaption"></div>
          </div>
        </div>

        <div class="btn-row between">
          <a class="btn btn-ghost" href="#/write" data-link>← 다시 쓰기</a>
          <div style="display:flex;gap:12px;">
            <button class="btn" id="foldBtn">접기 시작</button>
            <button class="btn btn-primary" id="toSend" disabled>미리보고 보내기</button>
          </div>
        </div>
      </section>`;

    const paper = $('#origami');
    const result = $('#foldResult');
    const foldBtn = $('#foldBtn');
    const toSend = $('#toSend');
    let folded = false;

    function setFold(k) {
      draft.fold = k;
      $$('.fold-opt').forEach(o => o.setAttribute('aria-pressed', o.dataset.fold === k));
      // 접는 형태를 바꾸면 다시 접도록 초기화
      resetFold();
    }
    function resetFold() {
      folded = false;
      paper.classList.remove('folding');
      paper.style.display = '';
      result.classList.remove('show');
      foldBtn.textContent = '접기 시작';
      foldBtn.disabled = false;
      toSend.disabled = true;
    }

    $('#foldPick').addEventListener('click', (e) => {
      const b = e.target.closest('.fold-opt');
      if (b) setFold(b.dataset.fold);
    });

    function doFold() {
      if (folded) return;
      foldBtn.disabled = true;
      // 접힘 애니메이션 시작
      void paper.offsetWidth; // 리플로우로 애니메이션 재시작 보장
      paper.classList.add('folding');

      const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      const delay = reduce ? 60 : 3100;

      setTimeout(() => {
        paper.style.display = 'none';
        const f = FOLDS[draft.fold];
        $('#frShape').innerHTML = foldIcon(draft.fold, 84);
        $('#frShape').style.background = foldColor(draft.fold);
        $('#frCaption').innerHTML = `${f.name}로 접었어요<small>${f.tag}</small>`;
        result.classList.add('show');
        folded = true;
        foldBtn.textContent = '다시 접기';
        foldBtn.disabled = false;
        toSend.disabled = false;
      }, delay);
    }

    foldBtn.addEventListener('click', () => {
      if (folded) { resetFold(); }
      else { doFold(); }
    });

    toSend.addEventListener('click', () => go('/preview'));
  }

  /* =========================================================
     화면: 완성 편지 미리보기
     ========================================================= */
  function renderPreview() {
    if (!draft.message.trim()) { go('/write'); return; }
    const f = FOLDS[draft.fold];

    app.innerHTML = `
      <section class="view">
        ${stepper('send')}
        <h2 class="section-title">이렇게 전해집니다</h2>
        <p class="section-sub">받는 사람은 접힌 ${f.name}${eul(f.name)} 톡 펼쳐, 편지를 읽게 돼요.</p>

        <div style="display:grid;grid-template-columns:0.8fr 1.1fr;gap:28px;align-items:center;" class="preview-grid">
          <div style="text-align:center;">
            <div class="preview-shape" style="background:${foldColor(draft.fold)}">
              ${foldIcon(draft.fold, 64)}
            </div>
            <div style="font-weight:700;font-size:1.05rem;color:var(--ink);margin-top:14px;">접힌 ${f.name}</div>
          </div>
          <div class="letter-preview" style="background-color:${paperColor(draft.paper)}">
            <div class="lp-to">${draft.to ? esc(draft.to) + '에게' : ''}</div>
            <div class="lp-body">${esc(draft.message)}</div>
            <div class="lp-from">${draft.from ? '— ' + esc(draft.from) : ''}</div>
          </div>
        </div>

        <div class="btn-row between" style="margin-top:24px;">
          <a class="btn btn-ghost" href="#/fold" data-link>← 다시 접기</a>
          <button class="btn btn-primary" id="confirmSend">편지 보내기</button>
        </div>
      </section>`;

    $('#confirmSend').addEventListener('click', () => go('/send'));

    // 모바일에서 한 컬럼
    const mq = window.matchMedia('(max-width: 640px)');
    if (mq.matches) {
      const g = $('.preview-grid'); if (g) g.style.gridTemplateColumns = '1fr';
    }
  }

  /* =========================================================
     화면: 전송 (공유 링크 생성)
     ========================================================= */
  function renderSend() {
    if (!draft.message.trim()) { go('/write'); return; }
    const f = FOLDS[draft.fold];

    const letter = {
      to: draft.to.trim(),
      from: draft.from.trim(),
      message: draft.message,
      fold: draft.fold,
      paper: draft.paper,
      date: Date.now()
    };
    const encoded = encodeLetter(letter);
    const base = location.href.split('#')[0];
    const link = `${base}#/open=${encoded}`;

    // 보낸 편지함에 보관
    const sent = load(STORE.sent);
    sent.unshift(Object.assign({ id: 'm' + letter.date }, letter));
    save(STORE.sent, sent);

    app.innerHTML = `
      <section class="view">
        <div class="send-card">
          <div class="sc-shape" style="background:${foldColor(draft.fold)}">${foldIcon(draft.fold, 52)}</div>
          <h2 class="section-title" style="margin-top:6px;">편지를 접어 두었어요</h2>
          <p class="section-sub" style="margin-bottom:8px;">
            아래 링크를 ${draft.to ? esc(draft.to) + '님께' : '받는 분께'} 건네주세요.<br/>
            링크를 연 사람은 접힌 ${f.name}${eul(f.name)} 펼쳐 편지를 읽게 됩니다.</p>

          <div class="share-box">
            <input id="shareLink" type="text" readonly value="${esc(link)}" />
            <button class="btn" id="copyBtn">복사</button>
          </div>
          <p class="share-hint">링크 안에 편지 내용이 담겨 있어, 서버 없이도 그대로 전해집니다.</p>

          <div class="btn-row" style="justify-content:center;margin-top:18px;">
            <button class="btn btn-ghost" id="previewOpen">내가 먼저 펼쳐보기</button>
            <a class="btn btn-primary" href="#/write" data-link id="writeAgain">새 편지 쓰기</a>
          </div>
        </div>
      </section>`;

    $('#copyBtn').addEventListener('click', async () => {
      const input = $('#shareLink');
      try {
        await navigator.clipboard.writeText(input.value);
        toast('링크를 복사했어요.');
      } catch (e) {
        input.select();
        document.execCommand && document.execCommand('copy');
        toast('링크를 복사했어요.');
      }
    });

    $('#previewOpen').addEventListener('click', () => go('/open=' + encoded));

    $('#writeAgain').addEventListener('click', () => {
      // 새 편지를 위해 초안 비우기
      draft.to = ''; draft.from = ''; draft.message = ''; draft.fold = 'plane'; draft.paper = 'cream';
    });
  }

  /* =========================================================
     화면: 받은 편지 열기 (펼침)
     ========================================================= */
  function renderOpen(encoded) {
    const letter = decodeLetter(encoded);
    if (!letter || !letter.message) {
      app.innerHTML = `
        <section class="view">
          <div class="empty-state">
            <div class="es-mark">${foldIcon('envelope', 60)}</div>
            <h2 class="section-title">편지를 펼칠 수 없어요</h2>
            <p>링크가 손상되었거나 일부만 복사된 것 같아요.</p>
            <a class="btn btn-primary" href="#/home" data-link>처음으로</a>
          </div>
        </section>`;
      return;
    }

    // 받은 편지함에 보관 (중복 방지)
    const recvId = 'r' + (letter.date || '');
    const received = load(STORE.received);
    if (!received.some(m => m.id === recvId)) {
      received.unshift(Object.assign({ id: recvId, read: false }, letter));
      save(STORE.received, received);
    }
    updateInboxBadge();

    const f = FOLDS[letter.fold] || FOLDS.plane;

    app.innerHTML = `
      <section class="view">
        <div class="open-stage">
          <div class="open-intro">
            <p class="oi-from">${letter.from ? esc(letter.from) + '님이' : '누군가'} 편지를 보냈어요</p>
            <p class="section-sub" style="margin:6px 0 0;">접힌 ${f.name}${eul(f.name)} 눌러 펼쳐 보세요.</p>
          </div>
          <div id="openSlot">
            <div class="sealed" id="sealed" style="background:${foldColor(letter.fold)}">${foldIcon(letter.fold, 88)}</div>
          </div>
        </div>
      </section>`;

    function unfold() {
      const slot = $('#openSlot');
      slot.innerHTML = `
        <div class="unfold-paper" style="background-color:${paperColor(letter.paper)}">
          <div class="uf-to">${letter.to ? esc(letter.to) + '에게' : '받는 이에게'}</div>
          <div class="uf-body">${esc(letter.message)}</div>
          <div class="uf-from">${letter.from ? '— ' + esc(letter.from) : ''}</div>
        </div>
        <div class="btn-row" style="justify-content:center;margin-top:24px;">
          <a class="btn btn-primary" href="#/write" data-link>나도 답장 쓰기</a>
          <a class="btn btn-ghost" href="#/inbox" data-link>편지함에 보관됨</a>
        </div>`;
      // 읽음 처리
      const list = load(STORE.received);
      const m = list.find(x => x.id === recvId);
      if (m) { m.read = true; save(STORE.received, list); updateInboxBadge(); }
    }

    $('#sealed').addEventListener('click', unfold);
  }

  /* =========================================================
     화면: 편지함
     ========================================================= */
  let inboxTab = 'received';
  function renderInbox() {
    const received = load(STORE.received);
    const sent = load(STORE.sent);
    const list = inboxTab === 'received' ? received : sent;

    app.innerHTML = `
      <section class="view">
        <h2 class="section-title">편지함</h2>
        <p class="section-sub">주고받은 편지를 모아 둡니다. (이 기기에 보관돼요)</p>

        <div class="inbox-tabs">
          <button data-tab="received" aria-pressed="${inboxTab === 'received'}">받은 편지 (${received.length})</button>
          <button data-tab="sent" aria-pressed="${inboxTab === 'sent'}">보낸 편지 (${sent.length})</button>
        </div>

        <div id="mailWrap"></div>
      </section>`;

    $('.inbox-tabs').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-tab]');
      if (!b) return;
      inboxTab = b.dataset.tab;
      renderInbox();
    });

    const wrap = $('#mailWrap');
    if (!list.length) {
      wrap.innerHTML = `
        <div class="empty-state">
          <div class="es-mark">${foldIcon(inboxTab === 'received' ? 'envelope' : 'plane', 60)}</div>
          <p>${inboxTab === 'received' ? '아직 받은 편지가 없어요.' : '아직 보낸 편지가 없어요.'}</p>
          <a class="btn btn-primary" href="#/write" data-link>편지 쓰러 가기</a>
        </div>`;
      return;
    }

    wrap.innerHTML = `<div class="mail-grid">` + list.map(m => {
      const f = FOLDS[m.fold] || FOLDS.plane;
      const hasName = inboxTab === 'received' ? !!m.from : !!m.to;
      const who = inboxTab === 'received'
        ? (m.from ? esc(m.from) : '누군가')
        : (m.to ? esc(m.to) : '받는 이');
      const whoLabel = !hasName ? '' : (inboxTab === 'received' ? '님' : '님께');
      const snippet = esc(String(m.message).replace(/\s+/g, ' ').slice(0, 50));
      const unread = inboxTab === 'received' && !m.read;
      return `
        <button class="mail-item" data-open="${encodeLetter({
          to: m.to, from: m.from, message: m.message, fold: m.fold, paper: m.paper, date: m.date
        })}">
          ${unread ? '<span class="mi-unread"></span>' : ''}
          <div class="mi-top"><span class="mi-ic" style="background:${foldColor(m.fold)}">${foldIcon(m.fold, 20)}</span><span class="mi-who">${who}${whoLabel}</span></div>
          <div class="mi-snippet">${snippet}${String(m.message).length > 50 ? '…' : ''}</div>
          <div class="mi-date">${formatDate(m.date)} · ${f.name}</div>
        </button>`;
    }).join('') + `</div>`;

    wrap.addEventListener('click', (e) => {
      const b = e.target.closest('.mail-item');
      if (b) go('/open=' + b.dataset.open);
    });
  }

  /* =========================================================
     링크 가로채기 (해시 라우팅) + 초기화
     ========================================================= */
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[data-link]');
    if (a) {
      // 해시 링크는 기본 동작으로도 동작하지만, 일관성 위해 명시 처리
      const href = a.getAttribute('href');
      if (href && href.indexOf('#') === 0) {
        e.preventDefault();
        location.hash = href.slice(1);
      }
    }
  });

  window.addEventListener('hashchange', router);
  window.addEventListener('DOMContentLoaded', () => {
    updateInboxBadge();
    router();
  });
  // DOMContentLoaded가 이미 지난 경우 대비
  if (document.readyState !== 'loading') {
    updateInboxBadge();
    router();
  }
})();
